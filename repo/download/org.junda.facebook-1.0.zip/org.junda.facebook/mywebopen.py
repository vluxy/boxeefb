def open(url):
    import sys
    import os
    p=sys.platform
    url='"'+url+'"'
    if p[:3] == "win":
        return os.startfile(url)
    if p == "darwin":
        return os.system("open "+url)
#TODO linux
    return os.system("xdg-open "+url)
