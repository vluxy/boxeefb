Facebook photos v1.0

Hi, the long-wanted Facebook app is here. Now you can view all your friends' photos on boxee, with slideshow!

It's being actively developed, and welcome to vote for new features here:
http://spreadsheets.google.com/viewform?formkey=cnQ5MDhqRGJRUEpyaUN0am1qNUFJV0E6MA..

Manual install:
1. Download boxeefb-1.0.zip file from http://code.google.com/p/boxeefb/downloads
2. Unzip, and copy the facebook folder to BOXEE/UserData/apps/
3. Add below to the pictures section of your sources.xml
	<source>
            <name>Facebook</name>
            <path>app://facebook/</path>
            <thumbnail>http://boxeefb.googlecode.com/files/logo200.png</thumbnail>
            <private>false</private>
        </source>
4. In your web browser, log out Facebook (recommended, to avoid re-login)
5. Run boxee, and navigate to Pictures-Internet-Facebook
6. Click "Login to Facebook", a Facebook login page will open in your browser
7. Fill the login form and check "Keep me logged in", submit
8. Go back to boxee, click OK and Enjoy!

AppBox install:
Coming soon!

Apple TV users:
A browser is needed for Facebook login. Or you can copy a working registry.xml from other computers to ATV. See "Configuration file" below for details.

Linux users:
This app uses xdg-open to open Facebook URL

Configuration file
The file can be found at BOXEE/UserData/profiles/yourboxeename/apps/facebook/registry.xml.
The content should look like:
<registry>
    <value id="expires">0</value>
    <value id="secret">989f61c2252837be36bd3f7fa5e5a211</value>
    <value id="session_key">a7d4515138a9076751c633db-632728111</value>
    <value id="uid">your facebook uid</value>
</registry>

If the value of "expires" is not 0, you have to re-login to Facebook in about 24 hours. Although it's well handled, it may be very annoying for some users. Steps to solve this:
1. in browser, logout Facebook
2. delete registry.xml
3. run boxee and this app, click "Login to Facebook"
4. in browser, check "Keep me logged in to boxee" before submit
5. Enjoy!

Source code and modification:
The source code is included in the app, no separate download needed. Feel free to modify the source code, but please keep the Facebook app key and original author Junda Liu. Thanks!

Bug report:
http://code.google.com/p/boxeefb/issues/

Known issues:
1. If friend name has non-ASCII character, the user id will be displayed, because the SetLabel API seems to accept ASCII only. If you know the solution, please contact the author at jundaliu+boxee@gmail.com
